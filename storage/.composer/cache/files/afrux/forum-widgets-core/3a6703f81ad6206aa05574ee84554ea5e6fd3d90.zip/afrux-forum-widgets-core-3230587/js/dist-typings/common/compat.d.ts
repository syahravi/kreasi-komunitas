import Widgets from './extend/Widgets';
import Widget from './components/Widget';
declare const _default: {
    'extensions/afrux-forum-widgets-core/common/extend/Widgets': typeof Widgets;
    'extensions/afrux-forum-widgets-core/common/components/Widget': typeof Widget;
};
export default _default;

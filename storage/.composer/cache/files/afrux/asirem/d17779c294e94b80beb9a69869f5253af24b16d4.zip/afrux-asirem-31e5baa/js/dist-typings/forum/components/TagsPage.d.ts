export default class TagsPage {
    view(): JSX.Element;
}

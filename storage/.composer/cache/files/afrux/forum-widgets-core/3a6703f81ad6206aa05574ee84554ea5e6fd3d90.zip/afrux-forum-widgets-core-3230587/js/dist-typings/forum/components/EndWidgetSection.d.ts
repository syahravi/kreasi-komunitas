import * as Mithril from 'mithril';
import Component from 'flarum/common/Component';
export default class EndWidgetSection extends Component {
    view(): Mithril.Children;
}

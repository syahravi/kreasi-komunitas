declare const _default: {
    'extensions/afrux-forum-widgets-core/common/extend/Widgets': typeof import("../common/extend/Widgets").default;
    'extensions/afrux-forum-widgets-core/common/components/Widget': typeof import("../common/components/Widget").default;
};
export default _default;

import * as Mithril from 'mithril';
import Component from 'flarum/common/Component';
export default class StartBottomWidgetSection extends Component {
    view(): Mithril.Children;
}

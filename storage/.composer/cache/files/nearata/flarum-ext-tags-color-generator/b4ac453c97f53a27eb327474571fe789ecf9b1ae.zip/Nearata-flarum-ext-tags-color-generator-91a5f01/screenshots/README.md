# Screenshots

The extension adds:

- Color Luminosity field
- Color Hue Field
- Generate Random Color button


![](ss_1.png)

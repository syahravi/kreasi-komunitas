export { Swiper } from 'swiper';
export { Navigation, Pagination, Zoom } from 'swiper/modules';

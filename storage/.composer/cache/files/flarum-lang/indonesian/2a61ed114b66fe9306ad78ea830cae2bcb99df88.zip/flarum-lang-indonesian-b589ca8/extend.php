<?php

return [
	new Flarum\Extend\LanguagePack(),
];

module.exports = require('flarum-webpack-config')();

<p align=center>
<img src="https://lh3.googleusercontent.com/-Qv3zxyMvp7Y/YNn_uUZ_kcI/AAAAAAAAFdg/ejtHkbrrZoUCadfaPtRZawTHVNqUrkFlgCLcBGAsYHQ/s16000/theme-base_alt.png" alt="logo">
</p><h1 align=center><b>Afrux</b> Theme Base</h1><p align=center>
<img alt="License" src="https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square"> <a href="https://packagist.org/packages/afrux/flarum-theme-base"><img alt="Latest Stable Version" src="https://img.shields.io/packagist/v/afrux/flarum-theme-base.svg?style=flat-square"></a> <a href="https://packagist.org/packages/afrux/flarum-theme-base"><img alt="Total Downloads" src="https://img.shields.io/packagist/dt/afrux/flarum-theme-base.svg?style=flat-square"></a> <a href="https://www.buymeacoffee.com/sycho"><img alt="donate" src="https://img.shields.io/badge/donate-buy%20me%20a%20coffee-%23ffde39?style=flat-square"></a><br>
A Flarum library as a base package for shared code between Afrux themes.
</p>

### Links

- [Packagist](https://packagist.org/packages/afrux/flarum-theme-base)
- [GitHub](https://github.com/afrux/flarum-theme-base)

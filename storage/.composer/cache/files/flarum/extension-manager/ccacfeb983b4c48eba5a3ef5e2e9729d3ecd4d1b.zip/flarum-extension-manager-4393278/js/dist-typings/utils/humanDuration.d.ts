export default function humanDuration(start: Date, end: Date): string;

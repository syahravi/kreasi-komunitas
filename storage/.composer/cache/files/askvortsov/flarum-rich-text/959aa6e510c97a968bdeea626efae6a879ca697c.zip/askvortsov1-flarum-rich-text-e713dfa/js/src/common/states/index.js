import MenuState from './MenuState';

export const states = {
  MenuState: MenuState,
};

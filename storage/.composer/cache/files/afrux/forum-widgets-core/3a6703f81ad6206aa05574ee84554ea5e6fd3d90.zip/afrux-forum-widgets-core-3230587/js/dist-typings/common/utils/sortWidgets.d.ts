import { Widget } from '../extend/Widgets';
export default function sortWidgets(widgets: Widget[]): Widget[];

# Contributing

Contributions are **welcome** and will be fully **credited**.

We accept contributions via Pull Requests on [Github](https://github.com/omines/oauth2-gitlab). Follow
[good standards](http://www.phptherightway.com/), keep code coverage at 100%, and run `bin/prepare-commit`
before committing.

<?php

namespace League\OAuth2\Client\Provider\Exception;

use Exception;

class FacebookProviderException extends Exception
{
}

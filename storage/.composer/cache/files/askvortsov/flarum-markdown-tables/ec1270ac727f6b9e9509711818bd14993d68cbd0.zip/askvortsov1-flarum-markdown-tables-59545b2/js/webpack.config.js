module.exports = require('flarum-webpack-config')({
    useExtensions: ['askvortsov-rich-text']
});

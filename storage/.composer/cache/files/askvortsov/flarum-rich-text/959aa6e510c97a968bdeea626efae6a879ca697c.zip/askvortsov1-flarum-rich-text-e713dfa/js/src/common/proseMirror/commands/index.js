import updateToggleMark from './updateToggleMark';

export const commands = {
  updateToggleMark: updateToggleMark,
};
